package project;

import java.util.ArrayList;

public class Shop {
	public static Shop s;
	private int item_no;
	private String item_name;
	private int item_price;
	
	//getter and setter
	
	
	
	
	public int getItem_no() {
		return item_no;
	}

	public void setItem_no(int item_no) {
		this.item_no = item_no;
	}
	

	public String getItem_name() {
		return item_name;
	}

	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}
	

	public int getItem_price() {
		return item_price;
	}

	public void setItem_price(int item_price) {
		this.item_price = item_price;
	}
	
	//Functions
	public void addNewItem(Shop s)
	{
		this.item_no = s.item_no;
		this.item_name = s.item_name;
		this.item_price = s.item_price;
	}

	public void displayallItems(ArrayList<Shop> arr)
	{
		System.out.println("\n\n");
		if(arr.isEmpty())
		{
			System.out.println("No Item...");
			return;
		}
		System.out.println("Item No \t\t\t\t\t\t Item Name  \t\t\t\t\t\t Item Price  \t\t\t\t\t\t");
		System.out.println("............................................ ");

		for (Shop shop : arr)
		{
			
			System.out.println(shop.item_no+ "\t\t\t\t\t\t" +shop.item_name+" \t\t\t\t\t\t" +shop.item_price);

		}
		System.out.println("............................................ ");
		System.out.println("\n\n");
}

}

	

	 