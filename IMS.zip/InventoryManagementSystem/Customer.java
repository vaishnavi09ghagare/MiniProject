package project;

import java.util.ArrayList;

public class Customer {
	
	private static final int purchase_qty = 0;
	private int customer_id;
	private String customer_name;
	private int customer_qty;
	private int item_no;
	private float total_Bill; 
	
	public void addCustomerDetails(Customer c)
	{
		this.customer_name =c.customer_name;
		this.customer_qty = c.customer_qty;
		this.item_no = c.item_no;
		
	}
	
	public <shop> void DisplayCustomerBill(ArrayList<Customer> arr , String cus_name,ArrayList<shop> shoplist)
	{
		float total =0;
		System.out.println("Item No \t\t Item Name  \t\t Item Price");
		System.out.println("\n\n............................................ \n\n");

		for(Customer c : arr)
		{
			if(c.customer_name.equals(cus_name))
			{
				System.out.println(c.item_no+ "\t\t" +c.customer_name+ "\t\t" +Customer.purchase_qty);
				for(shop shop : shoplist)
				{
					if(((Object) shop).getNo() ==c.item_no)
					{
						total +=Customer.purchase_qty * 1 ;

					}
				}
			}
		
		}	
		System.out.println("\n\n............................................ \n\n");
		
		System.out.println("Total Bill Before Discount == * + total");
		float dis = 0;
		if(total < 200){
			dis = (total*15)/100;
		}
		else 
			if(total > 700){
				dis = (total*50)/100;
			}
		System.out.println("\n\n............................................ \n\n");

		
		System.out.println("Total Bill After Discount == * + (total -dis)");
	}
	
	
	//getter and setter
	
	public float getTotal_Bill() {
		return total_Bill;
	}

	public void setTotal_Bill(float total_Bill) {
		this.total_Bill = total_Bill;
	}

	public String getCustomer_name() {
		return customer_name;
	}
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}
	
	public int getCustomer_qty() {
		return customer_qty;
	}

	public void setCustomer_qty(int customer_qty) {
		this.customer_qty = customer_qty;
	}
	
	public int getItem_no() {
		return item_no;
	}

	public void setItem_no(int item_no) {
		this.item_no = item_no;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		

	}

	public int getCustomer_id() {
		return customer_id;
	}

	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}

	public void setPurchase_qty(int nextInt) {
		// TODO Auto-generated method stub
		
	}

	

}
