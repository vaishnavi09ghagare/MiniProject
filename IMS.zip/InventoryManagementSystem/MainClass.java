package project;

import java.util.Scanner;
import java.util.ArrayList;


public class MainClass {

	static void menu() {
		System.out.println("1- Add New Item ");
		System.out.println("2- Display all Item ");
		System.out.println("3- Add Customer Details");
		System.out.println("4- EXIT ");
	}
	
	
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int opt;
		Scanner sc = new Scanner(System.in);
		Shop s = new Shop();
		ArrayList<Shop> shopList = new ArrayList <Shop>();
		ArrayList<Customer> cusList = new ArrayList <Customer>();

		do{
			Shop.s = new Shop();
			menu();
			opt = sc.nextInt();
			switch(opt)
			{
			case 1:
				System.out.println("Enter Item No : ");
				s.setNo(sc.nextInt());
				System.out.println("Enter Item Name : ");
				sc = new Scanner(System.in);
				sc.next();
				s.setName(sc.nextLine());
				System.out.println("Enter Item price : ");
				s.setPrice(sc.nextInt());
				s.addNewItem(s);
				shopList.add(s);	
				break;
			case 2:
				s.displayItem(shopList);
				break;
			case 3:
				_sellOutDetails();
				break;
			default:
				break;
			}
		}
		while(opt !=0);
	}





	private static void _sellOutDetails()
	{
		Scanner sc = new Scanner(System.in);
		Customer c = new Customer();
		System.out.println("Enter Customer Name : ");
		c.setCustomer_name(sc.nextLine());
		System.out.println("Enter Item No : ");
		c.setItem_no(sc.nextInt());
		System.out.println("Enter Item Qty : ");
		c.setPurchase_qty(sc.nextInt());
		
		c.AddCustomerDetails(c);
		cusList.add(c);
		
		System.out.println("Do You Have More Items? (Y/N");
		String choice = "";
		sc.nextLine();
		if(choice.contains("yes") == true)
		{
			//Again input and update data of customer
			_sellOutDetails();
		}
		else
		{
			//display bill
			c.DisplayCustomerBill(cusList ,c.getCustomer_name());
		}
		
		
		
		
	}

}
